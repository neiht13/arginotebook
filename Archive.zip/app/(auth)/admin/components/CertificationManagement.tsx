"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useSession } from "next-auth/react"
import { useToast } from "@/components/ui/use-toast"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { vi } from "date-fns/locale"
import { CalendarIcon, Plus, Pencil, Trash2, Search, Award, FileImage } from "lucide-react"
import { cn } from "@/lib/utils"
import Spinner  from "@/components/ui/spinner"
import { EmptyState } from "@/components/ui/empty-state"
import axios from "axios"

// Định nghĩa kiểu dữ liệu cho chứng nhận
interface Certification {
  _id?: string
  userId: string
  name: string
  issuer: string
  issueDate: string
  expiryDate?: string
  description?: string
  imageUrl?: string
  status: "active" | "expired" | "revoked"
}

// Định nghĩa kiểu dữ liệu cho người dùng
interface User {
  _id: string
  accountId: string
  name: string
  email: string
  role: string[]
}

export default function CertificationManagement() {
  const { data: session } = useSession()
  const { toast } = useToast()

  // State cho danh sách chứng nhận và người dùng
  const [certifications, setCertifications] = useState<Certification[]>([])
  const [users, setUsers] = useState<User[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedUserId, setSelectedUserId] = useState<string>("")

  // State cho modal thêm/sửa chứng nhận
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [currentCertification, setCurrentCertification] = useState<Certification | null>(null)
  const [formData, setFormData] = useState<Certification>({
    userId: "",
    name: "",
    issuer: "",
    issueDate: format(new Date(), "yyyy-MM-dd"),
    expiryDate: "",
    description: "",
    imageUrl: "",
    status: "active",
  })

  // State cho upload hình ảnh
  const [isUploading, setIsUploading] = useState(false)
  const [previewImage, setPreviewImage] = useState<string | null>(null)

  // Fetch dữ liệu khi component mount
  useEffect(() => {
    fetchData()
  }, [])

  // Fetch dữ liệu khi chọn người dùng khác
  useEffect(() => {
    if (selectedUserId) {
      fetchCertifications(selectedUserId)
    } else {
      fetchCertifications()
    }
  }, [selectedUserId])

  // Fetch danh sách người dùng và chứng nhận
  const fetchData = async () => {
    setIsLoading(true)
    try {
      // Fetch danh sách người dùng
      const usersResponse = await axios.get("/api/users")
      setUsers(usersResponse.data)

      // Fetch danh sách chứng nhận
      await fetchCertifications()
    } catch (error) {
      console.error("Error fetching data:", error)
      toast({
        title: "Lỗi",
        description: "Không thể tải dữ liệu. Vui lòng thử lại sau.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Fetch danh sách chứng nhận (có thể lọc theo userId)
  const fetchCertifications = async (userId?: string) => {
    try {
      const url = userId ? `/api/certifications?userId=${userId}` : "/api/certifications"
      const response = await axios.get(url)
      setCertifications(response.data)
    } catch (error) {
      console.error("Error fetching certifications:", error)
      toast({
        title: "Lỗi",
        description: "Không thể tải danh sách chứng nhận.",
        variant: "destructive",
      })
    }
  }

  // Mở modal thêm chứng nhận mới
  const handleAddNew = () => {
    setCurrentCertification(null)
    setFormData({
      userId: selectedUserId || "",
      name: "",
      issuer: "",
      issueDate: format(new Date(), "yyyy-MM-dd"),
      expiryDate: "",
      description: "",
      imageUrl: "",
      status: "active",
    })
    setPreviewImage(null)
    setIsModalOpen(true)
  }

  // Mở modal sửa chứng nhận
  const handleEdit = (certification: Certification) => {
    setCurrentCertification(certification)
    setFormData({
      ...certification,
      issueDate: certification.issueDate
        ? format(new Date(certification.issueDate), "yyyy-MM-dd")
        : format(new Date(), "yyyy-MM-dd"),
      expiryDate: certification.expiryDate ? format(new Date(certification.expiryDate), "yyyy-MM-dd") : "",
    })
    setPreviewImage(certification.imageUrl || null)
    setIsModalOpen(true)
  }

  // Xử lý thay đổi input form
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  // Xử lý thay đổi select
  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  // Xử lý thay đổi ngày
  const handleDateChange = (name: string, date: Date | undefined) => {
    if (date) {
      setFormData((prev) => ({ ...prev, [name]: format(date, "yyyy-MM-dd") }))
    }
  }

  // Xử lý upload hình ảnh
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Tạo preview
    const reader = new FileReader()
    reader.onloadend = () => {
      const result = reader.result as string
      setPreviewImage(result)
    }
    reader.readAsDataURL(file)

    // Upload hình ảnh
    setIsUploading(true)
    try {
      const formData = new FormData()
      formData.append("image", file)
      formData.append("userId", selectedUserId || session?.user.uId || "")

      const response = await axios.post("/api/certifications/upload", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      })

      if (response.data.url) {
        setFormData((prev) => ({ ...prev, imageUrl: response.data.url }))
        toast({
          title: "Thành công",
          description: "Đã tải lên hình ảnh chứng nhận.",
        })
      }
    } catch (error) {
      console.error("Error uploading image:", error)
      toast({
        title: "Lỗi",
        description: "Không thể tải lên hình ảnh. Vui lòng thử lại.",
        variant: "destructive",
      })
    } finally {
      setIsUploading(false)
    }
  }

  // Xử lý submit form
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.name || !formData.issuer || !formData.issueDate) {
      toast({
        title: "Lỗi",
        description: "Vui lòng điền đầy đủ thông tin bắt buộc.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)
    try {
      if (currentCertification?._id) {
        // Cập nhật chứng nhận
        await axios.put("/api/certifications", {
          _id: currentCertification._id,
          ...formData,
        })
        toast({
          title: "Thành công",
          description: "Đã cập nhật thông tin chứng nhận.",
        })
      } else {
        // Thêm chứng nhận mới
        await axios.post("/api/certifications", formData)
        toast({
          title: "Thành công",
          description: "Đã thêm chứng nhận mới.",
        })
      }

      // Đóng modal và refresh dữ liệu
      setIsModalOpen(false)
      fetchCertifications(selectedUserId)
    } catch (error) {
      console.error("Error saving certification:", error)
      toast({
        title: "Lỗi",
        description: "Không thể lưu thông tin chứng nhận. Vui lòng thử lại.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  // Xử lý xóa chứng nhận
  const handleDelete = async (id: string) => {
    if (!confirm("Bạn có chắc chắn muốn xóa chứng nhận này không?")) {
      return
    }

    try {
      await axios.delete(`/api/certifications/${id}`)
      toast({
        title: "Thành công",
        description: "Đã xóa chứng nhận.",
      })
      fetchCertifications(selectedUserId)
    } catch (error) {
      console.error("Error deleting certification:", error)
      toast({
        title: "Lỗi",
        description: "Không thể xóa chứng nhận. Vui lòng thử lại.",
        variant: "destructive",
      })
    }
  }

  // Lọc danh sách chứng nhận theo từ khóa tìm kiếm
  const filteredCertifications = certifications.filter(
    (cert) =>
      cert.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      cert.issuer.toLowerCase().includes(searchTerm.toLowerCase()) ||
      cert.description?.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  // Tìm tên người dùng từ ID
  const getUserName = (userId: string) => {
    const user = users.find((u) => u.accountId === userId)
    return user ? user.name : "Không xác định"
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-xl font-bold">Quản lý chứng nhận/chứng chỉ</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col space-y-4">
          <div className="flex flex-col sm:flex-row justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="relative w-full sm:w-64">
                <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
                <Input
                  placeholder="Tìm kiếm chứng nhận..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              <Select value={selectedUserId} onValueChange={(value) => setSelectedUserId(value)}>
                <SelectTrigger className="w-full sm:w-64">
                  <SelectValue placeholder="Chọn người dùng" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tất cả người dùng</SelectItem>
                  {users.map((user) => (
                    <SelectItem key={user.accountId} value={user.accountId}>
                      {user.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Button onClick={handleAddNew} className="bg-lime-500 hover:bg-lime-600">
              <Plus className="mr-2 h-4 w-4" />
              Thêm chứng nhận
            </Button>
          </div>

          {isLoading ? (
            <div className="flex justify-center items-center py-8">
              <Spinner size="lg" />
            </div>
          ) : filteredCertifications.length === 0 ? (
            <EmptyState
              icon={<Award className="h-10 w-10 text-slate-400" />}
              title="Không có chứng nhận"
              description="Chưa có chứng nhận nào được thêm vào hệ thống."
              action={
                <Button onClick={handleAddNew} className="bg-lime-500 hover:bg-lime-600">
                  <Plus className="mr-2 h-4 w-4" />
                  Thêm chứng nhận
                </Button>
              }
            />
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Tên chứng nhận</TableHead>
                    <TableHead>Đơn vị cấp</TableHead>
                    <TableHead>Người dùng</TableHead>
                    <TableHead>Ngày cấp</TableHead>
                    <TableHead>Trạng thái</TableHead>
                    <TableHead className="text-right">Thao tác</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredCertifications.map((cert) => (
                    <TableRow key={cert._id}>
                      <TableCell className="font-medium">{cert.name}</TableCell>
                      <TableCell>{cert.issuer}</TableCell>
                      <TableCell>{getUserName(cert.userId)}</TableCell>
                      <TableCell>{cert.issueDate ? format(new Date(cert.issueDate), "dd/MM/yyyy") : "N/A"}</TableCell>
                      <TableCell>
                        <span
                          className={cn("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium", {
                            "bg-green-100 text-green-800": cert.status === "active",
                            "bg-yellow-100 text-yellow-800": cert.status === "expired",
                            "bg-red-100 text-red-800": cert.status === "revoked",
                          })}
                        >
                          {cert.status === "active" && "Còn hiệu lực"}
                          {cert.status === "expired" && "Hết hạn"}
                          {cert.status === "revoked" && "Đã thu hồi"}
                        </span>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="outline" size="icon" onClick={() => handleEdit(cert)} className="h-8 w-8">
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => handleDelete(cert._id!)}
                            className="h-8 w-8 text-red-500 hover:text-red-600"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </div>
      </CardContent>

      {/* Modal thêm/sửa chứng nhận */}
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>{currentCertification ? "Cập nhật chứng nhận" : "Thêm chứng nhận mới"}</DialogTitle>
            <DialogDescription>Điền thông tin chứng nhận/chứng chỉ của người dùng.</DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSubmit}>
            <div className="grid gap-4 py-4">
              {/* Người dùng */}
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="userId" className="text-right">
                  Người dùng <span className="text-red-500">*</span>
                </Label>
                <div className="col-span-3">
                  <Select
                    value={formData.userId}
                    onValueChange={(value) => handleSelectChange("userId", value)}
                    disabled={!!selectedUserId}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Chọn người dùng" />
                    </SelectTrigger>
                    <SelectContent>
                      {users.map((user) => (
                        <SelectItem key={user.accountId} value={user.accountId}>
                          {user.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Tên chứng nhận */}
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="name" className="text-right">
                  Tên chứng nhận <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className="col-span-3"
                  required
                />
              </div>

              {/* Đơn vị cấp */}
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="issuer" className="text-right">
                  Đơn vị cấp <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="issuer"
                  name="issuer"
                  value={formData.issuer}
                  onChange={handleChange}
                  className="col-span-3"
                  required
                />
              </div>

              {/* Ngày cấp */}
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="issueDate" className="text-right">
                  Ngày cấp <span className="text-red-500">*</span>
                </Label>
                <div className="col-span-3">
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !formData.issueDate && "text-muted-foreground",
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {formData.issueDate ? (
                          format(new Date(formData.issueDate), "dd/MM/yyyy", { locale: vi })
                        ) : (
                          <span>Chọn ngày</span>
                        )}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={formData.issueDate ? new Date(formData.issueDate) : undefined}
                        onSelect={(date) => handleDateChange("issueDate", date)}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>

              {/* Ngày hết hạn */}
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="expiryDate" className="text-right">
                  Ngày hết hạn
                </Label>
                <div className="col-span-3">
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !formData.expiryDate && "text-muted-foreground",
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {formData.expiryDate ? (
                          format(new Date(formData.expiryDate), "dd/MM/yyyy", { locale: vi })
                        ) : (
                          <span>Chọn ngày</span>
                        )}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={formData.expiryDate ? new Date(formData.expiryDate) : undefined}
                        onSelect={(date) => handleDateChange("expiryDate", date)}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>

              {/* Trạng thái */}
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="status" className="text-right">
                  Trạng thái
                </Label>
                <div className="col-span-3">
                  <Select value={formData.status} onValueChange={(value) => handleSelectChange("status", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Chọn trạng thái" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Còn hiệu lực</SelectItem>
                      <SelectItem value="expired">Hết hạn</SelectItem>
                      <SelectItem value="revoked">Đã thu hồi</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Mô tả */}
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="description" className="text-right">
                  Mô tả
                </Label>
                <Textarea
                  id="description"
                  name="description"
                  value={formData.description || ""}
                  onChange={handleChange}
                  className="col-span-3"
                  rows={3}
                />
              </div>

              {/* Hình ảnh */}
              <div className="grid grid-cols-4 items-start gap-4">
                <Label htmlFor="imageUpload" className="text-right pt-2">
                  Hình ảnh
                </Label>
                <div className="col-span-3 space-y-2">
                  <div className="flex items-center gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => document.getElementById("imageUpload")?.click()}
                      disabled={isUploading}
                    >
                      <FileImage className="mr-2 h-4 w-4" />
                      Chọn hình ảnh
                    </Button>
                    <Input
                      id="imageUpload"
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handleImageUpload}
                      disabled={isUploading}
                    />
                    {isUploading && <Spinner size="sm" className="ml-2" />}
                  </div>

                  {previewImage && (
                    <div className="mt-2 relative">
                      <img
                        src={previewImage || "/placeholder.svg"}
                        alt="Preview"
                        className="max-h-[200px] rounded-md border border-slate-200"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        className="absolute top-2 right-2 h-8 w-8 bg-white/80 hover:bg-white"
                        onClick={() => {
                          setPreviewImage(null)
                          setFormData((prev) => ({ ...prev, imageUrl: "" }))
                        }}
                      >
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsModalOpen(false)} disabled={isSubmitting}>
                Hủy
              </Button>
              <Button type="submit" disabled={isSubmitting || isUploading} className="bg-lime-500 hover:bg-lime-600">
                {isSubmitting ? (
                  <>
                    <Spinner size="sm" className="mr-2" />
                    Đang lưu...
                  </>
                ) : currentCertification ? (
                  "Cập nhật"
                ) : (
                  "Thêm mới"
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </Card>
  )
}

