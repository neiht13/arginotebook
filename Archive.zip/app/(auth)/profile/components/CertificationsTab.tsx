"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useSession } from "next-auth/react"
import { useToast } from "@/components/ui/use-toast"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { vi } from "date-fns/locale"
import { Award, CalendarIcon, Building, FileImage, Plus, Pencil, Trash2 } from "lucide-react"
import { motion } from "framer-motion"
import  Spinner  from "@/components/ui/spinner"
import { EmptyState } from "@/components/ui/empty-state"
import { cn } from "@/lib/utils"
import axios from "axios"

// Định nghĩa kiểu dữ liệu cho chứng nhận
interface Certification {
  _id?: string
  userId: string
  name: string
  issuer: string
  issueDate: string
  expiryDate?: string
  description?: string
  imageUrl?: string
  status: "active" | "expired" | "revoked"
}

export default function CertificationsTab() {
  const { data: session } = useSession()
  const { toast } = useToast()
  const [certifications, setCertifications] = useState<Certification[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [selectedImage, setSelectedImage] = useState<string | null>(null)

  // State cho modal thêm/sửa chứng nhận
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [currentCertification, setCurrentCertification] = useState<Certification | null>(null)
  const [formData, setFormData] = useState<Certification>({
    userId: "",
    name: "",
    issuer: "",
    issueDate: format(new Date(), "yyyy-MM-dd"),
    expiryDate: "",
    description: "",
    imageUrl: "",
    status: "active",
  })

  // State cho upload hình ảnh
  const [isUploading, setIsUploading] = useState(false)
  const [previewImage, setPreviewImage] = useState<string | null>(null)

  // Fetch danh sách chứng nhận khi component mount
  useEffect(() => {
    if (session?.user?.uId) {
      fetchCertifications()
    }
  }, [session?.user?.uId])

  // Fetch danh sách chứng nhận của người dùng hiện tại
  const fetchCertifications = async () => {
    if (!session?.user?.uId) return

    setIsLoading(true)
    try {
      const response = await axios.get(`/api/certifications?userId=${session.user.uId}`)
      setCertifications(response.data)
    } catch (error) {
      console.error("Error fetching certifications:", error)
      toast({
        title: "Lỗi",
        description: "Không thể tải danh sách chứng nhận. Vui lòng thử lại sau.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Mở modal thêm chứng nhận mới
  const handleAddNew = () => {
    setCurrentCertification(null)
    setFormData({
      userId: session?.user?.uId || "",
      name: "",
      issuer: "",
      issueDate: format(new Date(), "yyyy-MM-dd"),
      expiryDate: "",
      description: "",
      imageUrl: "",
      status: "active",
    })
    setPreviewImage(null)
    setIsModalOpen(true)
  }

  // Mở modal sửa chứng nhận
  const handleEdit = (certification: Certification) => {
    setCurrentCertification(certification)
    setFormData({
      ...certification,
      issueDate: certification.issueDate
        ? format(new Date(certification.issueDate), "yyyy-MM-dd")
        : format(new Date(), "yyyy-MM-dd"),
      expiryDate: certification.expiryDate ? format(new Date(certification.expiryDate), "yyyy-MM-dd") : "",
    })
    setPreviewImage(certification.imageUrl || null)
    setIsModalOpen(true)
  }

  // Xử lý thay đổi input form
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  // Xử lý thay đổi select
  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  // Xử lý thay đổi ngày
  const handleDateChange = (name: string, date: Date | undefined) => {
    if (date) {
      setFormData((prev) => ({ ...prev, [name]: format(date, "yyyy-MM-dd") }))
    }
  }

  // Xử lý upload hình ảnh
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Tạo preview
    const reader = new FileReader()
    reader.onloadend = () => {
      const result = reader.result as string
      setPreviewImage(result)
    }
    reader.readAsDataURL(file)

    // Upload hình ảnh
    setIsUploading(true)
    try {
      const formData = new FormData()
      formData.append("image", file)
      formData.append("userId", session?.user?.uId || "")

      const response = await axios.post("/api/certifications/upload", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      })

      if (response.data.url) {
        setFormData((prev) => ({ ...prev, imageUrl: response.data.url }))
        toast({
          title: "Thành công",
          description: "Đã tải lên hình ảnh chứng nhận.",
        })
      }
    } catch (error) {
      console.error("Error uploading image:", error)
      toast({
        title: "Lỗi",
        description: "Không thể tải lên hình ảnh. Vui lòng thử lại.",
        variant: "destructive",
      })
    } finally {
      setIsUploading(false)
    }
  }

  // Xử lý submit form
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.name || !formData.issuer || !formData.issueDate) {
      toast({
        title: "Lỗi",
        description: "Vui lòng điền đầy đủ thông tin bắt buộc.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)
    try {
      if (currentCertification?._id) {
        // Cập nhật chứng nhận
        await axios.put("/api/certifications", {
          _id: currentCertification._id,
          ...formData,
        })
        toast({
          title: "Thành công",
          description: "Đã cập nhật thông tin chứng nhận.",
        })
      } else {
        // Thêm chứng nhận mới
        await axios.post("/api/certifications", formData)
        toast({
          title: "Thành công",
          description: "Đã thêm chứng nhận mới.",
        })
      }

      // Đóng modal và refresh dữ liệu
      setIsModalOpen(false)
      fetchCertifications()
    } catch (error) {
      console.error("Error saving certification:", error)
      toast({
        title: "Lỗi",
        description: "Không thể lưu thông tin chứng nhận. Vui lòng thử lại.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  // Xử lý xóa chứng nhận
  const handleDelete = async (id: string) => {
    if (!confirm("Bạn có chắc chắn muốn xóa chứng nhận này không?")) {
      return
    }

    try {
      await axios.delete(`/api/certifications/${id}`)
      toast({
        title: "Thành công",
        description: "Đã xóa chứng nhận.",
      })
      fetchCertifications()
    } catch (error) {
      console.error("Error deleting certification:", error)
      toast({
        title: "Lỗi",
        description: "Không thể xóa chứng nhận. Vui lòng thử lại.",
        variant: "destructive",
      })
    }
  }

  // Hiển thị trạng thái của chứng nhận
  const getStatusText = (status: string) => {
    switch (status) {
      case "active":
        return "Còn hiệu lực"
      case "expired":
        return "Hết hạn"
      case "revoked":
        return "Đã thu hồi"
      default:
        return "Không xác định"
    }
  }

  // Hiển thị màu sắc của trạng thái
  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800"
      case "expired":
        return "bg-yellow-100 text-yellow-800"
      case "revoked":
        return "bg-red-100 text-red-800"
      default:
        return "bg-slate-100 text-slate-800"
    }
  }

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { duration: 0.3 } },
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Spinner size="lg" />
      </div>
    )
  }

  return (
    <>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold text-slate-800">Chứng nhận của bạn</h2>
        <Button onClick={handleAddNew} className="bg-lime-500 hover:bg-lime-600">
          <Plus className="mr-2 h-4 w-4" />
          Thêm chứng nhận
        </Button>
      </div>

      {certifications.length === 0 ? (
        <EmptyState
          icon={<Award className="h-12 w-12 text-slate-400" />}
          title="Chưa có chứng nhận"
          description="Bạn chưa có chứng nhận nào. Hãy thêm chứng nhận để hiển thị ở đây."
          action={
            <Button onClick={handleAddNew} className="bg-lime-500 hover:bg-lime-600">
              <Plus className="mr-2 h-4 w-4" />
              Thêm chứng nhận
            </Button>
          }
        />
      ) : (
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {certifications.map((cert) => (
            <motion.div key={cert._id} variants={itemVariants}>
              <Card className="h-full flex flex-col overflow-hidden hover:shadow-md transition-shadow duration-200">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-lg font-bold text-slate-800">{cert.name}</CardTitle>
                    <span
                      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${getStatusColor(
                        cert.status,
                      )}`}
                    >
                      {getStatusText(cert.status)}
                    </span>
                  </div>
                  <CardDescription className="flex items-center text-slate-500">
                    <Building className="h-3.5 w-3.5 mr-1" />
                    {cert.issuer}
                  </CardDescription>
                </CardHeader>

                <CardContent className="pb-2 flex-grow">
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center text-slate-600">
                      <CalendarIcon className="h-4 w-4 mr-2 text-slate-400" />
                      <span>Ngày cấp: {format(new Date(cert.issueDate), "dd/MM/yyyy", { locale: vi })}</span>
                    </div>

                    {cert.expiryDate && (
                      <div className="flex items-center text-slate-600">
                        <CalendarIcon className="h-4 w-4 mr-2 text-slate-400" />
                        <span>Ngày hết hạn: {format(new Date(cert.expiryDate), "dd/MM/yyyy", { locale: vi })}</span>
                      </div>
                    )}

                    {cert.description && <p className="text-slate-600 mt-2 line-clamp-2">{cert.description}</p>}
                  </div>
                </CardContent>

                <CardFooter className="pt-2 flex justify-between">
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={() => handleEdit(cert)} className="h-8 px-2">
                      <Pencil className="h-3.5 w-3.5 mr-1" />
                      Sửa
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDelete(cert._id!)}
                      className="h-8 px-2 text-red-500 hover:text-red-600"
                    >
                      <Trash2 className="h-3.5 w-3.5 mr-1" />
                      Xóa
                    </Button>
                  </div>

                  {cert.imageUrl && (
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-8 px-2"
                          onClick={() => setSelectedImage(cert.imageUrl!)}
                        >
                          <FileImage className="h-3.5 w-3.5 mr-1" />
                          Xem ảnh
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-3xl">
                        <div className="flex flex-col items-center">
                          <h3 className="text-lg font-semibold mb-4">{cert.name}</h3>
                          <div className="relative w-full max-h-[70vh] overflow-auto">
                            <img
                              src={cert.imageUrl || "/placeholder.svg"}
                              alt={cert.name}
                              className="w-full h-auto object-contain"
                            />
                          </div>
                          <div className="mt-4 text-center text-sm text-slate-500">
                            <p>
                              {cert.issuer} - {format(new Date(cert.issueDate), "dd/MM/yyyy", { locale: vi })}
                            </p>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                  )}
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      )}

      {/* Modal thêm/sửa chứng nhận */}
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>{currentCertification ? "Cập nhật chứng nhận" : "Thêm chứng nhận mới"}</DialogTitle>
            <DialogDescription>Điền thông tin chứng nhận/chứng chỉ của bạn.</DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSubmit}>
            <div className="grid gap-4 py-4">
              {/* Tên chứng nhận */}
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="name" className="text-right">
                  Tên chứng nhận <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className="col-span-3"
                  required
                />
              </div>

              {/* Đơn vị cấp */}
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="issuer" className="text-right">
                  Đơn vị cấp <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="issuer"
                  name="issuer"
                  value={formData.issuer}
                  onChange={handleChange}
                  className="col-span-3"
                  required
                />
              </div>

              {/* Ngày cấp */}
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="issueDate" className="text-right">
                  Ngày cấp <span className="text-red-500">*</span>
                </Label>
                <div className="col-span-3">
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !formData.issueDate && "text-muted-foreground",
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {formData.issueDate ? (
                          format(new Date(formData.issueDate), "dd/MM/yyyy", { locale: vi })
                        ) : (
                          <span>Chọn ngày</span>
                        )}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={formData.issueDate ? new Date(formData.issueDate) : undefined}
                        onSelect={(date) => handleDateChange("issueDate", date)}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>

              {/* Ngày hết hạn */}
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="expiryDate" className="text-right">
                  Ngày hết hạn
                </Label>
                <div className="col-span-3">
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !formData.expiryDate && "text-muted-foreground",
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {formData.expiryDate ? (
                          format(new Date(formData.expiryDate), "dd/MM/yyyy", { locale: vi })
                        ) : (
                          <span>Chọn ngày</span>
                        )}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={formData.expiryDate ? new Date(formData.expiryDate) : undefined}
                        onSelect={(date) => handleDateChange("expiryDate", date)}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>

              {/* Trạng thái */}
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="status" className="text-right">
                  Trạng thái
                </Label>
                <div className="col-span-3">
                  <Select value={formData.status} onValueChange={(value) => handleSelectChange("status", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Chọn trạng thái" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Còn hiệu lực</SelectItem>
                      <SelectItem value="expired">Hết hạn</SelectItem>
                      <SelectItem value="revoked">Đã thu hồi</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Mô tả */}
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="description" className="text-right">
                  Mô tả
                </Label>
                <Textarea
                  id="description"
                  name="description"
                  value={formData.description || ""}
                  onChange={handleChange}
                  className="col-span-3"
                  rows={3}
                />
              </div>

              {/* Hình ảnh */}
              <div className="grid grid-cols-4 items-start gap-4">
                <Label htmlFor="imageUpload" className="text-right pt-2">
                  Hình ảnh
                </Label>
                <div className="col-span-3 space-y-2">
                  <div className="flex items-center gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => document.getElementById("imageUpload")?.click()}
                      disabled={isUploading}
                    >
                      <FileImage className="mr-2 h-4 w-4" />
                      Chọn hình ảnh
                    </Button>
                    <Input
                      id="imageUpload"
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handleImageUpload}
                      disabled={isUploading}
                    />
                    {isUploading && <Spinner size="sm" className="ml-2" />}
                  </div>

                  {previewImage && (
                    <div className="mt-2 relative">
                      <img
                        src={previewImage || "/placeholder.svg"}
                        alt="Preview"
                        className="max-h-[200px] rounded-md border border-slate-200"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        className="absolute top-2 right-2 h-8 w-8 bg-white/80 hover:bg-white"
                        onClick={() => {
                          setPreviewImage(null)
                          setFormData((prev) => ({ ...prev, imageUrl: "" }))
                        }}
                      >
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsModalOpen(false)} disabled={isSubmitting}>
                Hủy
              </Button>
              <Button type="submit" disabled={isSubmitting || isUploading} className="bg-lime-500 hover:bg-lime-600">
                {isSubmitting ? (
                  <>
                    <Spinner size="sm" className="mr-2" />
                    Đang lưu...
                  </>
                ) : currentCertification ? (
                  "Cập nhật"
                ) : (
                  "Thêm mới"
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </>
  )
}

