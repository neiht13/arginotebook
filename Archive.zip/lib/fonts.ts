import { Lexend as FontSans} from "next/font/google"
export const nunito = FontSans({
  subsets: ["latin"],
  variable: "--font-sans",
})
